#include<stdio.h>
void main()
{	
	int m,s;
	printf("Enter the score: \n");
	scanf("%d",&s);
	m=s/10;
	switch(m)
	{	case 4:
			printf("Pass\n");
			break;
		case 5:
			printf("Second Class\n");
			break;
		case 6:
			printf("First Class\n");
			break;
		case 7:
			printf("First Class\n");
			break;		
		case 8:
			printf("Distinction\n");
			break;
		case 9:
			printf("Distinction\n");
			break;
		case 1:
			printf("Congratulatios You Are A Topper\n");
			break;
		}		
}


