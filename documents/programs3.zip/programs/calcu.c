#include<stdio.h>
void main()
{
	float a,b,result;
	char op;
	printf("Enter the numbers : \n");
	scanf("%f %f",&a,&b);
	printf("Enter the operator +,-,* or / : \n");
	scanf("%c",&op);
	scanf("%c",&op);
	switch(op)
	{	case '+':
			result=a+b;
			break;
		case '-':
			result=a-b;
			break;
		case '*':
			result=a*b;
			break;
		case '/':
			result=a/b;
			break;
		default:
			printf("Invalid Operator\n");
			break;
	}
	
	printf("%f %c %f=%f",a,op,b,result);
}


