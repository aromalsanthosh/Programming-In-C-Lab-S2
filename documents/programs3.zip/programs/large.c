#include<stdio.h>
void main()
{
	int a,b;
	printf("Enter the numbers : \n");
	scanf("%d %d",&a,&b);
	if (a>b)
	{	
		printf("%d is large number",a);
	}
	else
	{
		printf("%d is large number",b);
	}

}

