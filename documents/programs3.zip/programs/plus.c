#include<stdio.h>
void main()
{
	int a;
	printf("Enter the number : \n");
	scanf("%d",&a);
	if (a>=0)
	{	
		printf("%d is positive",a);
	}
	else
	{
		printf("%d is negative",a);
	}

}

