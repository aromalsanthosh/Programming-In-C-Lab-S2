#include<stdio.h>
void main()
{
	int i;
	for (i=12;i>0;i--)
	{
		printf("%d \n",i);
	}
}
