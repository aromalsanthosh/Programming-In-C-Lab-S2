#include<stdio.h>
#include<math.h>
int main()
{
	int org,rem,n,r=0;
	printf("Enter the 3 digit number :\n");
	scanf("%d",&n);
	org=n;
	while(org!=0)
	{
		rem=n%10;
		r+=rem+rem+rem;
		n/=10;
		
	}
	if(r==n)
		printf("Number is Amstrong\n");
	else
		printf("Number is not Amstrong\n");
	return 0;	
}
