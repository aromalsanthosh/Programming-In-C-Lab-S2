#include<stdio.h>
void main()
{
	int i;
	for (i=7;i<=25;i++)
	{
		printf("%d \n",i);
	}
}
