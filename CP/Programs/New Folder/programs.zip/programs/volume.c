#include<stdio.h>
int main()
{
	int r;
	float pi=3.14,v;
	printf("Enter the radius :\n");
	scanf("%d",&r);
	v=(4*pi*r*r*r)/3;	
	printf("\n  Volume: %f",v);

}
	
