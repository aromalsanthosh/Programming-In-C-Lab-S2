#include<stdio.h>
int main()
{
	int a,b,r;
	printf("\n Enter the first number : ");
	scanf("%d",&a);
	printf(" \n Enter the second number :");
	scanf("%d",&b);
	r=a%b;
	printf("\nRemainder: %d",r);
}
