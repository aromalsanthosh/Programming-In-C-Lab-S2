#include<stdio.h>
void main()
{
	int a=5,b=6,c=3;
	int f1,f2,f3,f4;
	f1=a+(b*c);                   
	f2=(a*a)+b+c;
	f3=(a+b)*(a+c);
	f4=(a*b)+(b*c);
	printf("f1:%d\n",f1);
	printf("f2:%d\n",f2);
	printf("f3:%d\n",f3);
	printf("f4:%d\n",f4);
}
