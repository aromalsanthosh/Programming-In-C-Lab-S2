#include<stdio.h>
int main()
{
	int l=8,b=6,a;
	a=l*b;
	printf("\nArea: %d",a);

}
	
