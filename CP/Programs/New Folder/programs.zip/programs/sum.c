#include<stdio.h>
int main()
{
	int a,b,sum;
	printf("\n Enter the first number : ");
	scanf("%d",&a);
	printf(" \n Enter the second number :");
	scanf("%d",&b);
	sum=a+b;
	printf("\nsum: %d",sum);
}
