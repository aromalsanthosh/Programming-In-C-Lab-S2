#include<stdio.h>
int main()
{
	int a,b,q;
	printf("\n Enter the first number : ");
	scanf("%d",&a);
	printf(" \n Enter the second number :");
	scanf("%d",&b);
	q=a/b;
	printf("\nQuotient: %d",q);
}
