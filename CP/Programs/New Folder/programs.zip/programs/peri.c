#include<stdio.h>
int main()
{
	int pi=3.14,r=9,p;
	p=2*pi*r;
	printf("\nPerimeter: %d",p);

}
	
