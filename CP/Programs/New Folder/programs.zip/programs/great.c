#include<stdio.h>
void main()
{ 
	int a,b,r;
	printf("Enter value for a :\n");
	scanf("%d",&a);
	printf("Enter value for b :\n");
	scanf("%d",&b);
	r=(a>b)?a:b;
	printf("Result=%d \n",r);
	
}
